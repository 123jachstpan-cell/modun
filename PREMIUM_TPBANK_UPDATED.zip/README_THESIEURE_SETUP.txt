JACHST – BẢN TÍCH HỢP THESIEURE + TÀI KHOẢN KHÁCH HÀNG/ADMIN

CẤU TRÚC
- index.html: giao diện website Pages (có đăng ký/đăng nhập khách hàng và trang Admin #admin).
- worker.js: backend Cloudflare Worker.
- assets/: ảnh banner và GIF nhân vật.

PHẦN 1 – DEPLOY BACKEND WORKER
1. Cloudflare Dashboard → Workers & Pages → Create → Worker.
2. Tạo Worker tên ví dụ jachst-api, dán toàn bộ worker.js vào editor và Deploy.
3. Mở Settings → Bindings → Add → KV Namespace. Tạo KV namespace JACHST_DB và đặt Variable name chính xác là DB.
4. Mở Settings → Variables and Secrets và thêm:
   PARTNER_ID = Partner ID được cấp (Text/Variable).
   PARTNER_KEY = Partner Key được cấp (Secret).
   ADMIN_USER = tên đăng nhập Admin (Text/Variable hoặc Secret).
   ADMIN_PASS = mật khẩu Admin (Secret).
   CARD_API_URL = chỉ thêm nếu nhà cung cấp yêu cầu URL khác; mặc định https://thesieure.com/chargingws/v2.
5. Lưu thay đổi và Deploy lại Worker.

PHẦN 2 – CẤU HÌNH CALLBACK THESIEURE
- Trong phần quản lý API/Partner của nhà cung cấp, đặt callback URL: https://TEN-WORKER-CUA-BAN.workers.dev/callback
- Nhờ bộ phận hỗ trợ kích hoạt API nếu tài khoản chưa được kích hoạt.
- Đối chiếu chính xác base URL và công thức ký trong tài liệu gắn với tài khoản Partner của bạn. Source đang dùng công thức MD5: partner_key + code + command + partner_id + request_id + serial + telco.

PHẦN 3 – KẾT NỐI FRONTEND PAGES
1. Mở index.html bằng Acode hoặc trình sửa mã.
2. Tìm dòng API_BASE:"".
3. Thay bằng URL Worker thực tế, ví dụ API_BASE:"https://jachst-api.TEN-TAI-KHOAN.workers.dev".
4. Lưu index.html và upload lại toàn bộ nội dung thư mục lên Cloudflare Pages.
5. Worker đã giới hạn CORS cho https://napkimcuonglau.pages.dev. Nếu đổi tên miền Pages, sửa Access-Control-Allow-Origin trong worker.js theo domain mới rồi Deploy lại.

PHẦN 4 – ADMIN VÀ KHÁCH HÀNG
- Khách hàng: đăng ký/đăng nhập ngay trên website. Dữ liệu tài khoản và số dư lưu trong KV DB.
- Admin: mở https://napkimcuonglau.pages.dev/#admin rồi đăng nhập bằng ADMIN_USER / ADMIN_PASS.
- Admin có thể xem đơn, xác nhận đơn đã giao, chỉnh thông tin liên hệ và tỉ lệ quy đổi.
- Partner Key chỉ nằm trong Worker Secret; không nhập vào HTML và không lưu trong KV.

LƯU Ý QUAN TRỌNG
- Không gửi Partner Key hoặc mật khẩu Admin trong chat.
- Không dùng thẻ thật để thử. Hãy yêu cầu nhà cung cấp môi trường thử nghiệm hoặc test theo quy trình họ cấp.
- PRICES trong worker.js phải khớp giá PRODUCTS trong index.html.
- Bản này giữ các luồng đăng ký/đăng nhập, lịch sử, giỏ hàng, nạp thẻ, callback và Admin sẵn có. Chế độ giả lập trên trình duyệt đã được gỡ; cần cấu hình API_BASE và Worker để đăng nhập/giao dịch hoạt động.
- API đổi thẻ chỉ xử lý nạp thẻ vào ví; giao kim cương vẫn do Admin xác nhận thủ công trong source hiện tại.

PHẦN 5 – QR CHUYỂN KHOẢN TPBANK
- Website đã đặt sẵn ngân hàng TPB (TPBank), số tài khoản 97720082010 và chủ tài khoản TRAN TUAN ANH theo thông tin được cung cấp.
- QR được tạo động theo từng tài khoản khách hàng. Nội dung chuyển khoản hiển thị dạng: ID WEB NAPxxxxxx. Giữ nguyên mã NAPxxxxxx để hệ thống đối chiếu đúng tài khoản.
- Thesieure dùng cho luồng nạp thẻ cào; không tự nhận biết giao dịch chuyển khoản ngân hàng.
- Worker có endpoint /sepay. Muốn tự cộng số dư từ chuyển khoản, cần kết nối dịch vụ thông báo giao dịch ngân hàng tương thích với endpoint này và đặt SEPAY_KEY dưới dạng Secret trong Worker. Nếu chưa cấu hình webhook, Admin phải kiểm tra giao dịch và xác nhận thủ công.
- Nếu Worker đã có cấu hình ngân hàng cũ được lưu trong KV, mở Admin → cấu hình QR ngân hàng và cập nhật lại: TPB / 97720082010 / TRAN TUAN ANH, sau đó lưu.



PHẦN 6 – DANH MỤC ROBLOX VÀ LỊCH SỬ ĐƠN HÀNG
- Giao diện có ba nút truy cập nhanh: Nạp tiền, Đơn hàng, Thông báo & CSKH.
- Tài khoản hiển thị riêng Nạp tiền, Đơn hàng và Lịch sử giao dịch.
- Worker có endpoint GET /orders; endpoint chỉ trả về các đơn có trường user trùng với tài khoản đăng nhập.
- Quản trị viên chuyển trạng thái đơn từ Chờ xử lý sang Đang xử lý hoặc Đã giao; trạng thái được phản ánh ở mục Đơn hàng của khách.
- Robux dùng ID sản phẩm 7–12. Giá hiện tại theo các mức giá Free Fire trong source: 10.000 / 20.000 / 50.000 / 100.000 / 200.000 / 500.000đ. Lượng Robux trong từng gói là cấu hình ban đầu trong index.html và worker.js, cần chủ shop kiểm tra lại chính sách giá và phương thức giao thực tế trước khi bật bán.
- Mỗi đơn chỉ chứa sản phẩm của một trò chơi; không thể gộp Robux và kim cương Free Fire vào cùng một đơn.
- Đơn Robux và Free Fire hiện được ghi nhận để Admin xử lý thủ công; source chưa tích hợp API tự động giao Robux/kim cương.
- Sau khi cập nhật, deploy lại cả worker.js lên Cloudflare Worker và toàn bộ website (index.html + assets) lên Pages. Không chỉ tải riêng index.html nếu đang triển khai từ thư mục build khác.
