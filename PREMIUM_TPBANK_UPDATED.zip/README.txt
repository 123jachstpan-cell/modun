JACHST – SHOP FREE FIRE & ROBLOX (BẢN BỔ SUNG)

- Trang web: index.html
- Backend Cloudflare: worker.js
- Ảnh: assets/
- Có nút truy cập nhanh: Nạp tiền, Đơn hàng, Thông báo & CSKH.
- Tài khoản có các mục: Nạp tiền, Đơn hàng, Lịch sử giao dịch.
- Danh mục sản phẩm: Free Fire và Roblox (Robux).
- Robux đang dùng cùng các mức giá VND với gói Free Fire: 10.000 / 20.000 / 50.000 / 100.000 / 200.000 / 500.000đ. Số Robux tương ứng được khai báo trong index.html và worker.js; cần đối chiếu giá/nguồn giao thực tế trước khi mở bán.
- QR ngân hàng: TPBank (TPB), STK 97720082010, chủ tài khoản TRAN TUAN ANH.
- Nội dung chuyển khoản: ID WEB + mã NAPxxxxxx riêng của tài khoản khách.
- Thesieure xử lý nạp thẻ cào. Chuyển khoản ngân hàng tự cộng số dư chỉ hoạt động khi đã cấu hình webhook SePay/SEPAY_KEY; nếu chưa, Admin xác nhận thủ công.
- Endpoint mới: GET /orders (trả đơn hàng của tài khoản đang đăng nhập).
- Đơn hàng vẫn do Admin xử lý thủ công; thay đổi trạng thái trong Admin sẽ hiển thị ở mục Đơn hàng của khách.
- Đọc README_THESIEURE_SETUP.txt để triển khai.

BẢN TIẾP THEO – CẢI TIẾN THEO DÕI ĐƠN
- Mục Đơn hàng có nút tải lại dữ liệu, nút sao chép mã đơn và lối mở nhanh hướng dẫn/CSKH.
- Trạng thái đơn được tô màu riêng: Chờ xử lý, Đang xử lý, Đã giao, Đã hủy.
- Lịch sử giao dịch có nút tải lại; hiển thị mã giao dịch, thời gian, trạng thái và ghi chú.
- Tên ngân hàng trong hướng dẫn QR lấy theo cấu hình CFG.BANK thay vì cố định chữ TPBank.
- Kiểm tra cú pháp JavaScript frontend và Cloudflare Worker bằng Node.js: đạt.
