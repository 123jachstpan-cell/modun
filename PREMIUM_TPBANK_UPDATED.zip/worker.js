// GameShop backend – Cloudflare Worker
// Cần cấu hình:
//   KV namespace gắn tên: DB
//   KV namespace binding: DB
//   Variables/Secrets: PARTNER_ID, PARTNER_KEY, ADMIN_USER, ADMIN_PASS
//   Optional variable: CARD_API_URL (mặc định https://thesieure.com/chargingws/v2)
//   Optional secret: SEPAY_KEY
// Callback URL Thesieure: https://<worker>.workers.dev/callback
// API Key chỉ lưu trong Worker Variables/Secrets, không lưu trong KV hay frontend.
// Giá phải khớp với PRODUCTS trong index.html (server luôn tự tính tiền, không tin giá từ trình duyệt)
const PRICES = { 1: 10000, 2: 20000, 3: 50000, 4: 100000, 5: 200000, 6: 500000, 7: 10000, 8: 20000, 9: 50000, 10: 100000, 11: 200000, 12: 500000 };
const NAMES = { 1: "500 Kim cương", 2: "1.250 Kim cương", 3: "5.000 Kim cương (PRO)", 4: "12.500 Kim cương (PRO)", 5: "30.000 Kim cương (VIP)", 6: "100.000 Kim cương (VIP)", 7: "200 Robux", 8: "500 Robux", 9: "1.500 Robux", 10: "5.000 Robux", 11: "15.000 Robux", 12: "50.000 Robux" };
const PRODUCT_GAMES = { 1: "Free Fire", 2: "Free Fire", 3: "Free Fire", 4: "Free Fire", 5: "Free Fire", 6: "Free Fire", 7: "Roblox", 8: "Roblox", 9: "Roblox", 10: "Roblox", 11: "Roblox", 12: "Roblox" };

// Chỉ cho phép frontend Pages chính thức gọi API. Nếu đổi domain Pages, cập nhật origin này.
const H = {
  "Access-Control-Allow-Origin": "https://napkimcuonglau.pages.dev",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Max-Age": "86400",
  "Vary": "Origin",
  "Content-Type": "application/json",
};
const out = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: H });
const fail = (error, s = 200) => out({ ok: false, error }, s);
const hex = (b) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
const md5 = async (s) => hex(await crypto.subtle.digest("MD5", new TextEncoder().encode(s)));
const rnd = (n = 16) => hex(crypto.getRandomValues(new Uint8Array(n)));
async function cfg(env) {
  let saved = {};
  try {
    saved = JSON.parse((await env.DB.get("cfg")) || "{}");
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) saved = {};
  } catch {
    saved = {};
  }

  const oldNotice = "Chào mừng đến PREMIUM! Kim cương chỉ dùng trong game JACHST. Cần hỗ trợ liên hệ Telegram hoặc Zalo ở cuối trang.";
  const oldFreeFireNotice = "CHÀO MỪNG BẠN ĐÃ ĐẾN VỚI SHOP KIM CƯƠNG FREEFIRE\nNẠP RÚT 30S\nMUA KIM CƯƠNG DONE SIÊU TỐC\nUY TÍN\nHỖ TRỢ";
  if (saved.notice === oldNotice || saved.notice === oldFreeFireNotice) {
    saved.notice = "CHÀO MỪNG BẠN ĐẾN VỚI PREMIUM – SHOP FREE FIRE & ROBLOX\nNạp tiền qua QR ngân hàng hoặc thẻ cào.\nChọn gói Free Fire hoặc Robux, theo dõi đơn hàng trong tài khoản.\nHỗ trợ khách hàng qua Telegram và Zalo ở cuối trang.";
  }

  const merged = {
    card_rate: 0.8,
    bank: "TPB",
    acc: "97720082010",
    name: "TRAN TUAN ANH",
    notice: "CHÀO MỪNG BẠN ĐẾN VỚI PREMIUM – SHOP FREE FIRE & ROBLOX\nNạp tiền qua QR ngân hàng hoặc thẻ cào.\nChọn gói Free Fire hoặc Robux, theo dõi đơn hàng trong tài khoản.\nHỗ trợ khách hàng qua Telegram và Zalo ở cuối trang.",
    tele: "",
    zalo: "",
    ...saved,
    // Thông tin đối tác chỉ đọc từ Worker Variables/Secrets; không lưu khóa trong KV.
    partner_id: env.PARTNER_ID || "",
    partner_key: env.PARTNER_KEY || "",
  };
  const rate = Number(merged.card_rate);
  merged.card_rate = Number.isFinite(rate) && rate > 0 && rate <= 1 ? rate : 0.8;
  return merged;
}

async function hashPw(pw, salt) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: 100000, hash: "SHA-256" }, k, 256));
}
const getU = async (env, n) => {
  try {
    const u = JSON.parse((await env.DB.get("u:" + n)) || "null");
    if (!u || typeof u !== "object") return null;
    if (!Array.isArray(u.txs)) u.txs = [];
    if (!Number.isFinite(Number(u.balance))) u.balance = 0;
    return u;
  } catch {
    return null;
  }
};
const putU = (env, u) => env.DB.put("u:" + u.name, JSON.stringify(u));
function addTx(u, o) {
  if (!Array.isArray(u.txs)) u.txs = [];
  const t = { id: "G" + Date.now() + Math.floor(Math.random() * 99), time: Date.now(), status: "ok", ...o };
  u.txs.unshift(t);
  u.txs = u.txs.slice(0, 200);
  return t;
}
async function auth(req, env) {
  const header = req.headers.get("Authorization") || "";
  const match = /^Bearer ([a-f0-9]{32})$/i.exec(header);
  if (!match) return null;
  const name = await env.DB.get("s:" + match[1]);
  return name ? getU(env, name) : null;
}
async function session(env, name) {
  const t = rnd();
  await env.DB.put("s:" + t, name, { expirationTtl: 60 * 60 * 24 * 30 });
  return t;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname;
    if (req.method === "OPTIONS") return new Response(null, { headers: H });
    const C = await cfg(env);
    const body = req.method === "POST" && p !== "/callback" ? await req.json().catch(() => ({})) : {};

    // ---- Đăng ký / đăng nhập ----
    if (p === "/register") {
      const name = String(body.name || "").toLowerCase();
      if (!/^[a-z0-9_]{3,20}$/.test(name) || String(body.pass || "").length < 6) return fail("Thông tin không hợp lệ");
      if (await getU(env, name)) return fail("Tên đã tồn tại");
      const salt = rnd(8);
      const code = "NAP" + (100000 + Math.floor(Math.random() * 900000));
      const u = { name, salt, hash: await hashPw(body.pass, salt), balance: 0, txs: [], code };
      await putU(env, u);
      await env.DB.put("c:" + code, name); // tra ngược mã nạp → user (cho SePay)
      return out({ ok: true, token: await session(env, name) });
    }
    if (p === "/login") {
      const u = await getU(env, String(body.name || "").toLowerCase());
      if (!u || (await hashPw(String(body.pass || ""), u.salt)) !== u.hash) return fail("Sai tên hoặc mật khẩu");
      return out({ ok: true, token: await session(env, u.name) });
    }

    // ---- Nhà cung cấp gọi vào (không cần đăng nhập, tự xác thực) ----
    if (p === "/callback") {
      if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
      if (!C.partner_key) return new Response("callback not configured", { status: 503 });
      // Nhà cung cấp có thể gửi callback dạng form-data, x-www-form-urlencoded hoặc JSON.
      const f = Object.fromEntries(url.searchParams);
      try {
        const ct = req.headers.get("content-type") || "";
        if (ct.includes("application/json")) Object.assign(f, await req.json());
        else Object.assign(f, Object.fromEntries(await req.formData()));
      } catch { /* dùng các trường query nếu callback gửi qua URL */ }
      const owner = await env.DB.get("r:" + String(f.request_id || ""));
      if (!owner) return new Response("not found", { status: 404 });
      const r = JSON.parse(owner);
      if (f.callback_sign !== (await md5(C.partner_key + r.code + r.serial))) return new Response("bad sign", { status: 403 });
      const u = await getU(env, r.user);
      if (!u || !Array.isArray(u.txs)) return new Response("user not found", { status: 404 });
      const t = u.txs.find((x) => x.id === f.request_id);
      if (t && t.status === "pending") {
        const st = Number(f.status);
        if (st === 1 || st === 2) {
          const faceValue = Number(f.value);
          if (!Number.isFinite(faceValue) || faceValue <= 0) {
            return new Response("bad value", { status: 400 });
          }
          const v = Math.floor(faceValue * Number(C.card_rate));
          if (!Number.isFinite(v) || v <= 0) return new Response("bad amount", { status: 400 });
          t.status = "ok";
          t.amount = v;
          u.balance = Number(u.balance || 0) + v;
        } else {
          t.status = "fail";
          t.note = (t.note || "") + " – " + (f.message || "Thẻ sai");
        }
        await putU(env, u);
      }
      return new Response("OK");
    }
    if (p === "/sepay") {
      if (!env.SEPAY_KEY || req.headers.get("Authorization") !== "Apikey " + env.SEPAY_KEY) {
        return new Response("no", { status: 401 });
      }
      const transferId = String(body.id || "").slice(0, 100);
      const transferAmount = Number(body.transferAmount);
      if (
        body.transferType !== "in" ||
        !transferId ||
        !Number.isSafeInteger(transferAmount) ||
        transferAmount <= 0 ||
        (await env.DB.get("sp:" + transferId))
      ) return out({ success: true });
      const m = String(body.content || "").toUpperCase().match(/NAP\d{6}/);
      const name = m && (await env.DB.get("c:" + m[0]));
      if (name) {
        const u = await getU(env, name);
        if (u) {
          u.balance = Number(u.balance || 0) + transferAmount;
          addTx(u, { type: "topup_bank", amount: transferAmount, note: "Chuyển khoản " + m[0] });
          await putU(env, u);
          await env.DB.put("sp:" + transferId, "1", { expirationTtl: 60 * 60 * 24 * 30 }); // chống cộng trùng
        }
      }
      return out({ success: true });
    }

    // ---- Công khai + Quản trị ----
    if (p === "/config") return out({ ok: true, notice: C.notice, tele: C.tele, zalo: C.zalo, bank: C.bank, acc: C.acc, name: C.name, card_rate: C.card_rate });
    if (p === "/admin/login") {
      if (!env.ADMIN_USER || !env.ADMIN_PASS || body.user !== env.ADMIN_USER || body.pass !== env.ADMIN_PASS) return fail("Sai thông tin quản trị");
      const t = rnd();
      await env.DB.put("a:" + t, "1", { expirationTtl: 60 * 60 * 8 });
      return out({ ok: true, token: t });
    }
    if (p.startsWith("/admin/")) {
      const t = (req.headers.get("Authorization") || "").replace("Bearer ", "");
      if (!t || !(await env.DB.get("a:" + t))) return fail("Chưa đăng nhập admin", 401);
      if (p === "/admin/config") {
        if (req.method === "POST") {
          const n = { ...C };
          // Không ghi thông tin đối tác vào KV; chỉ giữ trong Worker Variables/Secrets.
          delete n.partner_id;
          delete n.partner_key;
          for (const k of ["notice", "tele", "zalo", "bank", "acc", "name"]) if (typeof body[k] === "string") n[k] = body[k].slice(0, 500);
          const r = Number(body.card_rate);
          if (r > 0 && r <= 1) n.card_rate = r;
          await env.DB.put("cfg", JSON.stringify(n));
          return out({ ok: true });
        }
        return out({ ok: true, ...C, partner_key: "", has_key: !!C.partner_key });
      }
      if (p === "/admin/orders") {
        const l = await env.DB.list({ prefix: "o:", limit: 50 });
        const items = await Promise.all(l.keys.map(async (k) => {
          try { return JSON.parse(await env.DB.get(k.name)); } catch { return null; }
        }));
        return out({ ok: true, items: items.filter(Boolean).sort((a, b) => b.time - a.time) });
      }
      if (p === "/admin/orders/status" && req.method === "POST") {
        const id = String(body.id || "");
        const status = String(body.status || "");
        if (!/^O[a-zA-Z0-9]+$/.test(id) || !["processing", "completed"].includes(status)) {
          return fail("Thông tin cập nhật đơn không hợp lệ", 400);
        }
        const raw = await env.DB.get("o:" + id);
        if (!raw) return fail("Không tìm thấy đơn hàng", 404);
        const order = JSON.parse(raw);
        if (order.status === "cancelled") return fail("Đơn đã bị hủy");
        order.status = status;
        order.updated_at = Date.now();
        await env.DB.put("o:" + id, JSON.stringify(order));
        const customer = await getU(env, order.user);
        if (customer) {
          const tx = customer.txs.find((x) => x.order_id === id);
          if (tx) {
            tx.status = status;
            tx.note = (tx.note || "").replace(/ \[.*?\]$/, "") + (status === "completed" ? " [Đã giao thủ công]" : " [Đang xử lý]");
            await putU(env, customer);
          }
        }
        return out({ ok: true });
      }
      return fail("Không tìm thấy", 404);
    }

    // ---- Cần đăng nhập ----
    const u = await auth(req, env);
    if (!u) return fail("Chưa đăng nhập", 401);

    if (p === "/me") return out({ ok: true, name: u.name, balance: u.balance, code: u.code });
    if (p === "/history") return out({ ok: true, txs: u.txs });
    if (p === "/orders") {
      const l = await env.DB.list({ prefix: "o:", limit: 1000 });
      const items = await Promise.all(l.keys.map(async (k) => {
        try {
          const order = JSON.parse(await env.DB.get(k.name));
          return order && order.user === u.name ? order : null;
        } catch { return null; }
      }));
      return out({ ok: true, items: items.filter(Boolean).sort((a, b) => b.time - a.time).slice(0, 100) });
    }

    if (p === "/charge") {
      const { telco, amount, serial, code } = body;
      const faceValue = Number(amount);
      const allowedAmounts = [10000, 20000, 50000, 100000, 200000, 500000];
      const allowedTelcos = ["VIETTEL", "MOBIFONE", "VINAPHONE", "GARENA"];
      if (!/^\d{8,20}$/.test(String(serial || "")) || !/^\d{8,20}$/.test(String(code || ""))) {
        return fail("Serial/mã thẻ không hợp lệ");
      }
      if (!allowedTelcos.includes(String(telco || "").toUpperCase())) return fail("Nhà mạng không hợp lệ");
      if (!allowedAmounts.includes(faceValue)) return fail("Mệnh giá thẻ không hợp lệ");
      if (!C.partner_id || !C.partner_key) return fail("Chưa cấu hình tài khoản đối tác nạp thẻ");
      const rate = Number(C.card_rate);
      if (!Number.isFinite(rate) || rate <= 0 || rate > 1) return fail("Tỉ lệ nạp thẻ chưa được cấu hình hợp lệ");

      const request_id = "T" + Date.now() + rnd(4);
      const tx = addTx(u, {
        id: request_id, type: "topup_card", amount: 0, status: "pending",
        note: String(telco).toUpperCase() + " " + faceValue
      });
      await putU(env, u);
      // Lưu request trước khi gọi nhà cung cấp để callback đến sớm vẫn tìm thấy giao dịch.
      await env.DB.put("r:" + request_id, JSON.stringify({ user: u.name, code, serial }), {
        expirationTtl: 60 * 60 * 24 * 7
      });

      let d;
      try {
        const cardApiUrl = env.CARD_API_URL || "https://thesieure.com/chargingws/v2";
        const sign = await md5(C.partner_key + code + "charging" + C.partner_id + request_id + serial + String(telco).toUpperCase());
        const res = await fetch(cardApiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            telco: String(telco).toUpperCase(), code, serial, amount: String(faceValue),
            request_id, partner_id: C.partner_id,
            sign, command: "charging",
          }),
        });
        d = await res.json();
      } catch {
        // Không xóa giao dịch vì nhà cung cấp có thể đã nhận yêu cầu trước khi kết nối bị ngắt.
        return out({ ok: true, status: 99, message: "Chưa xác định kết quả; vui lòng kiểm tra Lịch sử trước khi gửi lại." });
      }
      // 99 = đang chờ; 1 = thẻ đúng; 2 = thẻ đúng nhưng sai mệnh giá.
      // Trạng thái 1/2 được đối soát và cộng ví qua callback đã xác thực chữ ký.
      if (![99, 1, 2].includes(Number(d.status))) {
        tx.status = "fail";
        tx.note += " – " + String(d.message || "Nhà cung cấp từ chối");
        await putU(env, u);
        await env.DB.delete("r:" + request_id);
        return fail(d.message || "Thẻ bị từ chối");
      }
      return out({ ok: true, status: 99 });
    }

    if (p === "/buy") {
      if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > Object.keys(PRICES).length) {
        return fail("Danh sách sản phẩm không hợp lệ");
      }
      const receiver = String(body.receiver || "").trim();
      if (!receiver || receiver.length > 40) return fail("ID người chơi không hợp lệ");

      let total = 0;
      const names = [];
      const seen = new Set();
      let selectedGame = "";
      for (const item of body.items) {
        const id = String(item?.id ?? "");
        const qty = Number(item?.qty);
        if (!Object.prototype.hasOwnProperty.call(PRICES, id) || seen.has(id) ||
            !Number.isInteger(qty) || qty < 1 || qty > 99) {
          return fail("Sản phẩm không hợp lệ");
        }
        seen.add(id);
        const game = PRODUCT_GAMES[id];
        if (selectedGame && selectedGame !== game) return fail("Không thể gộp sản phẩm của hai trò chơi trong cùng một đơn");
        selectedGame = game;
        total += PRICES[id] * qty;
        names.push(NAMES[id] + " ×" + qty);
      }
      if (!Number.isSafeInteger(total) || total <= 0) return fail("Tổng tiền không hợp lệ");
      if (Number(u.balance) < total) return fail("Số dư không đủ");

      const orderId = "O" + Date.now() + rnd(4);
      const order = {
        id: orderId, time: Date.now(), user: u.name, total,
        items: names.join(", "), receiver, game: selectedGame, status: "pending"
      };
      u.balance = Number(u.balance) - total;
      addTx(u, {
        type: "buy", amount: -total, status: "pending", order_id: orderId,
        note: names.join(", ") + " → " + receiver
      });
      await putU(env, u);
      await env.DB.put("o:" + orderId, JSON.stringify(order));
      // Chưa tích hợp API giao kim cương: đơn được ghi nhận để admin xử lý thủ công.
      return out({ ok: true, order_id: orderId, status: "pending" });
    }

    return fail("Không tìm thấy", 404);
  },
};
